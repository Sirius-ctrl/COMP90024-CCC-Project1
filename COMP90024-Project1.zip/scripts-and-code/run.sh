rm Archive.zip testCluster.py utils.py
rm -r __MACOSX
